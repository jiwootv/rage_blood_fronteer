import math

def attack_alg_main(pos1, pos2, r):
	d = math.sqrt((pos1[0]-pos2[0])**2 + (pos1[1]-pos2[1])**2)
	return d <= r

print(attack_alg_main((0, 0), (3, 0), 3))