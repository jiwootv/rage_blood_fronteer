class Inventory:
	def __init__(self):
		self.item_names = ["Notanium", "Notanium Ingot", "Notanium Nugget", "Notanium Bullet", "M1911", "WbRebolber", "Bread"]
